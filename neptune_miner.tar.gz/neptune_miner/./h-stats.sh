#!/usr/bin/env bash

. /hive/miners/custom/neptune_miner/h-manifest.conf

stats_raw=`curl -s --connect-timeout 3 --max-time 5 http://127.0.0.1:${MINER_API_PORT}`

if [[ $? -ne 0 || -z $stats_raw ]]; then
  khs=0
  stats="null"
else
  gpu_stats=$(< $GPU_STATS_JSON)

  readarray -t gpu_stats < <( jq --slurp -r -c '.[] | .busids, .brand, .temp, .fan | join(" ")' $GPU_STATS_JSON 2>/dev/null)
  busids=(${gpu_stats[0]})
  brands=(${gpu_stats[1]})
  temps=(${gpu_stats[2]})
  fans=(${gpu_stats[3]})
  gpu_count=${#busids[@]}

  if (( $(gpu-detect NVIDIA) > 0 )); then
    BRAND_MINER="nvidia"
  elif (( $(gpu-detect AMD) > 0 )); then
    BRAND_MINER="amd"
  else
    BRAND_MINER=""
  fi

  selected_idx=()
  for (( i=0; i<gpu_count; i++ )); do
    [[ "${brands[i]}" == "$BRAND_MINER" ]] && selected_idx+=("$i")
  done

  ac=0
  rj=0
  hr=0
  fan_arr=()
  temp_arr=()
  hash_arr=()
  busid_arr=()

  for (( j=0; j<${#selected_idx[@]}; j++ )); do
    i=${selected_idx[j]}

    [[ "${busids[i]}" =~ ^([A-Fa-f0-9]+): ]]
    fan_arr+=("${fans[i]}")
    temp_arr+=("${temps[i]}")
    busid_arr+=($((16#${BASH_REMATCH[1]})))

    hashrate=$(jq -r ".gpus[\"$j\"].hr // 0"       <<< "$stats_raw")
    accepted=$(jq -r ".gpus[\"$j\"].accepted // 0" <<< "$stats_raw")
    rejected=$(jq -r ".gpus[\"$j\"].rejected // 0" <<< "$stats_raw")

    hash_arr+=("$hashrate")
    ac=$(( ac + accepted ))
    rj=$(( rj + rejected ))
    hr=$(( hr + hashrate ))
  done

  fan_json=`printf '%s\n' "${fan_arr[@]}"  | jq -cs '.'`
  hash_json=`printf '%s\n' "${hash_arr[@]}" | jq -cs '.'`
  temp_json=`printf '%s\n' "${temp_arr[@]}"  | jq -cs '.'`
  bus_numbers=`printf '%s\n' "${busid_arr[@]}"  | jq -cs '.'`

  khs=$(( hr / 1000 ))
  version=$(echo "$stats_raw" | jq -cr ".version")
  uptime=$(echo "$stats_raw" | jq -r ".uptime_sec")

  stats=$(jq -nc \
    --arg ths "$hr" \
    --argjson ac "$ac" \
    --argjson rj "$rj" \
    --arg ver "$version" \
    --arg uptime "$uptime" \
    --argjson hs "$hash_json"\
    --argjson fan "$fan_json" \
    --argjson temp "$temp_json" \
    --argjson bus_numbers "$bus_numbers" \
    '{ hs: $hs, hs_units: "hs", "ths": $ths, algo : "neptune", ver:$ver, ar:[$ac,$rj], $uptime, $bus_numbers, $temp, $fan}')
fi

echo "$stats"

